library(TMB)
library(MASS)

compile("Poisson_AR1_Missing_Data.cpp")
dyn.load(dynlib("Poisson_AR1_Missing_Data"))

compile("Poisson_MA1_Missing_Data.cpp")
dyn.load(dynlib("Poisson_MA1_Missing_Data"))

compile("Poisson_EQC_Missing_Data.cpp")
dyn.load(dynlib("Poisson_EQC_Missing_Data"))

compile("NB_MA1_Missing_Data.cpp")
dyn.load(dynlib("NB_MA1_Missing_Data"))

compile("NB_EQC_Missing_Data.cpp")
dyn.load(dynlib("NB_EQC_Missing_Data"))

#********************************************************************
#*************** DGM : Poisson MA1 Mixed Effect Model  **************
#***************** Missing Completely at Random (MCAR) **************
#********************************************************************


set.seed(100)

n_sim = 5
n = 100
ni = 8

beta_true = c(0.5,0.5)
sigma2_tau_true = 0.5 
rho_true = 0.0
theta1_true = 0.5
k_true = 0.0


# Covariates X1, X2
X1 = matrix(NA, nrow = n, ncol = ni)
X2 = matrix(NA, nrow = n, ncol = ni)

# X1 Covariate

for (i in 1:n) {
  for (j in 1:ni) {
    if (i <= 0.25*n) {
      if (j %in% 1:4) X1[i,j] <- 0.5
      if (j %in% 5:8) X1[i,j] <- 1
    } else if (i <= 0.75*n) {
      if (j %in% 1:2) X1[i,j] <- -0.5
      if (j %in% 3:6) X1[i,j] <- 0
      if (j %in% 7:8) X1[i,j] <- 0.5
    } else {
      X1[i,j] <- j / (2*ni)
    }
  }
}


# X2 Covariate

for (i in 1:n) {
  for (j in 1:ni) {
    if (i <= 0.5*n) {
      X2[i,j] <- (j - (ni + 1)/2) / (2*ni)
    } else {
      if (j %in% 1:4) X2[i,j] <- 0
      if (j %in% 5:8) X2[i,j] <- 0.5
    }
  }
}


Poisson_MA1 = function(beta,sigma2_tau, theta1){
  
  Y = matrix(NA, nrow = n, ncol = ni)
  
  sigma_tau = sqrt(sigma2_tau)
  
  cov_tau <- matrix(0, ni, ni)
  for (i in 1:ni) {
    for (j in 1:ni) {
      if (i==j) cov_tau[i,j] = (1 + theta1^2)*sigma2_tau
      else if (abs(i-j) == 1) cov_tau[i,j] = theta1*sigma2_tau
      else cov_tau[i,j] = 0
    }
  }
  
  tau = matrix(0, n, ni)
  
  
  for (i in 1:n) {
    tau[i, ] = mvrnorm(1, mu = rep(0, ni), Sigma = cov_tau)
    
    for (j in 1:ni) {
      mu_ij= exp(X1[i,j]*beta[1] + X2[i,j]*beta[2] + tau[i,j])
      Y[i,j] = rpois(1, mu_ij)
    }
  }
  return(Y)
}



#**********************************
# Simulation Preparation
#**********************************

AICc <- matrix(NA, n_sim, 5)
colnames(AICc) <- c("AIC_AR_Pois", "AIC_MA_Pois", "AIC_EQC_Pois", "AIC_MA_NB", "AIC_EQC_NB")

BICc <- matrix(NA, n_sim, 5)
colnames(BICc) <- c("BIC_AR_Pois", "BIC_MA_Pois", "BIC_EQC_Pois", "BIC_MA_NB", "BIC_EQC_NB")

Pois_AR_better_AICc<-0
Pois_MA_better_AICc<-0
Pois_EQC_better_AICc<-0

Pois_AR_better_BICc<-0
Pois_MA_better_BICc<-0
Pois_EQC_better_BICc<-0

NB_MA_better_AICc<-0
NB_EQC_better_AICc<-0

NB_MA_better_BICc<-0
NB_EQC_better_BICc<-0

error_count1 <-0
error_count2 <-0
error_count3 <-0
error_count4 <-0
error_count5 <-0


Estimated_para <- data.frame(
  Pois_AR_beta1      = rep(NA, n_sim),
  Pois_AR_beta2      = rep(NA, n_sim),
  Pois_AR_sigma2_tau = rep(NA, n_sim),
  Pois_AR_rho        = rep(NA, n_sim),
  
  Pois_MA_beta1      = rep(NA, n_sim),
  Pois_MA_beta2      = rep(NA, n_sim),
  Pois_MA_sigma2_tau = rep(NA, n_sim),
  Pois_MA_theta1     = rep(NA, n_sim),
  
  Pois_EQC_beta1      = rep(NA, n_sim),
  Pois_EQC_beta2      = rep(NA, n_sim),
  Pois_EQC_sigma2_tau = rep(NA, n_sim),
  
  NB_MA_beta1      = rep(NA, n_sim),
  NB_MA_beta2      = rep(NA, n_sim),
  NB_MA_sigma2_tau = rep(NA, n_sim),
  NB_MA_theta1     = rep(NA, n_sim),
  NB_MA_k     = rep(NA, n_sim),
  
  NB_EQC_beta1      = rep(NA, n_sim),
  NB_EQC_beta2      = rep(NA, n_sim),
  NB_EQC_sigma2_tau = rep(NA, n_sim),
  NB_EQC_k     = rep(NA, n_sim))

#**********************************
# Monte Carlo Simulation
#**********************************

g1 <- 1:25 ; g2 <- 26:50 ;  g3 <- 51:75 ; g4 <- 76:100

missing_pct = c()

ii=1


while (ii <=n_sim){
  
  Y = Poisson_MA1(beta = beta_true, sigma2_tau = sigma2_tau_true, theta1 = theta1_true)
  
  complete_subjects <- c( sample(g1,8), sample(g2,7), sample(g3,8), sample(g4,7))
  
  delta = matrix(rbinom(n*ni, size = 1, prob = 0.50), nrow = n, ncol = ni)
  
  delta[complete_subjects, ] <- rep(1,ni)
  
  missing_pct[ii] = (1 - sum(delta) / (n*ni)) 
  
  N_obs <- sum(delta)
  
  
  data = list(
    Y = Y,
    X1 = X1,
    X2 = X2,
    delta = delta,
    n = n,
    ni = ni)
  
  
  #=====================
  #  Poisson AR(1) Model
  #=====================
  parameters_AR <- list(
    beta = c(0, 0),
    logit_rho = 0,
    log_sigma2_tau = 0,
    tau = rep(0, n))
  
  
  error_AR <- try( ( obj1 <- MakeADFun(data,parameters_AR,random = "tau",
                                       DLL="Poisson_AR1_Missing_Data",
                                       inner.control=list(maxit=50000,trace=F)) ),
                   silent=TRUE )
  
  obj1$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_AR)) {
    error_count1 = error_count1 + 1
    next
  }
  
  error_AR<-try( ( opt1<-nlminb(obj1$par,obj1$fn,obj1$gr,
                                control = list(trace=10,
                                               iter.max=10000,eval.max=10000,
                                               sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_AR)) {
    error_count1 = error_count1 + 1
    next
  }
  
  if (opt1$convergence != 0) {
    error_count1 = error_count1 + 1
    next
  }
  
  obj1$gr(opt1$par)
  rep_AR = obj1$report() 
  
  AIC_AR_Pois <- 2*opt1$objective + 2*length(obj1$par)
  BIC_AR_Pois <- 2*opt1$objective + log(N_obs)*length(obj1$par)
  
  
  #=====================
  #  Poisson MA(1) Model
  #=====================
  parameters_MA <- list(
    beta = c(0, 0),
    log_sigma2_tau = 0,
    tau = matrix(0, nrow = n, ncol = ni),
    logit_theta1 = 0)
  
  
  error_MA <- try( ( obj2 <- MakeADFun(data,parameters_MA,random = "tau",
                                       DLL="Poisson_MA1_Missing_Data",
                                       inner.control=list(maxit=50000,trace=F)) ),
                   silent=TRUE )
  
  obj2$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_MA)) {
    error_count2 = error_count2 + 1
    next
  }
  
  error_MA<-try( ( opt2<-nlminb(obj2$par,obj2$fn,obj2$gr,
                                control = list(trace=10,
                                               iter.max=10000,eval.max=10000,
                                               sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_MA)) {
    error_count2 = error_count2 + 1
    next
  }
  
  if (opt2$convergence != 0) {
    error_count2 = error_count2 + 1
    next
  }
  
  obj2$gr(opt2$par)
  rep_MA = obj2$report() 
  
  AIC_MA_Pois <- 2*opt2$objective + 2*length(obj2$par)
  BIC_MA_Pois <- 2*opt2$objective +  log(N_obs)*length(obj2$par)
  
  #=====================
  #  Poisson EQC Model
  #=====================
  parameters_EQC <- list(
    beta = c(0, 0),
    log_sigma2_tau = 0,
    tau = rep(0,n))
  
  
  error_EQC <- try( ( obj3 <- MakeADFun(data,parameters_EQC,random = "tau",
                                        DLL="Poisson_EQC_Missing_Data",
                                        inner.control=list(maxit=50000,trace=F)) ),
                    silent=TRUE )
  
  obj3$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_EQC)) {
    error_count3 = error_count3 + 1
    next
  }
  
  error_EQC <-try( ( opt3<-nlminb(obj3$par,obj3$fn,obj3$gr,
                                  control = list(trace=10,
                                                 iter.max=10000,eval.max=10000,
                                                 sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_EQC)) {
    error_count3 = error_count3 + 1
    next
  }
  
  if (opt3$convergence != 0) {
    error_count3 = error_count3 + 1
    next
  }
  
  obj3$gr(opt3$par)
  rep_EQC = obj3$report() 
  
  AIC_EQC_Pois <- 2*opt3$objective + 2*length(obj3$par)
  BIC_EQC_Pois <- 2*opt3$objective +  log(N_obs)*length(obj3$par)
  
  
  #=====================
  #  NB MA(1) Model
  #=====================
  parameters_MA_NB <- list(
    beta = c(0, 0),
    log_sigma2_tau = 0,
    tau = matrix(0, nrow = n, ncol = ni),
    logit_theta1 = 0,
    log_k = 0)
  
  
  error_MA_NB <- try( ( obj4 <- MakeADFun(data,parameters_MA_NB,random = "tau",
                                          DLL="NB_MA1_Missing_Data",
                                          inner.control=list(maxit=50000,trace=F)) ),
                      silent=TRUE )
  
  obj4$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_MA_NB)) {
    error_count4 = error_count4 + 1
    next
  }
  
  error_MA_NB <-try( ( opt4 <-nlminb(obj4$par,obj4$fn,obj4$gr,
                                     control = list(trace=10,
                                                    iter.max=10000,eval.max=10000,
                                                    sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_MA_NB)) {
    error_count4 = error_count4 + 1
    next
  }
  
  if (opt4$convergence != 0) {
    error_count4 = error_count4 + 1
    next
  }
  
  obj4$gr(opt4$par)
  rep_MA_NB = obj4$report() 
  
  AIC_MA_NB <- 2*opt4$objective + 2*length(obj4$par)
  BIC_MA_NB <- 2*opt4$objective +  log(N_obs)*length(obj4$par)
  
  #=====================
  #  NB EQC Model
  #=====================
  parameters_EQC_NB <- list(
    beta = c(0, 0),
    log_sigma2_tau = 0,
    tau = rep(0,n),
    log_k = 0)
  
  
  error_EQC_NB <- try( ( obj5 <- MakeADFun(data,parameters_EQC_NB,random = "tau",
                                           DLL="NB_EQC_Missing_Data",
                                           inner.control=list(maxit=50000,trace=F)) ),
                       silent=TRUE )
  
  obj5$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_EQC_NB)) {
    error_count5 = error_count5 + 1
    next
  }
  
  error_EQC_NB <-try( ( opt5<-nlminb(obj5$par,obj5$fn,obj5$gr,
                                     control = list(trace=10,
                                                    iter.max=10000,eval.max=10000,
                                                    sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_EQC_NB)) {
    error_count5 = error_count5 + 1
    next
  }
  
  if (opt5$convergence != 0) {
    error_count5 = error_count5 + 1
    next
  }
  
  obj5$gr(opt5$par)
  rep_EQC_NB = obj5$report() 
  
  AIC_EQC_NB <- 2*opt5$objective + 2*length(obj5$par)
  BIC_EQC_NB <- 2*opt5$objective +  log(N_obs)*length(obj5$par)
  
  
  #---------------------
  # Results
  #---------------------
  
  AICc[ii, ] <- c(AIC_AR_Pois, AIC_MA_Pois, AIC_EQC_Pois, AIC_MA_NB , AIC_EQC_NB)
  BICc[ii, ] <- c(BIC_AR_Pois, BIC_MA_Pois, BIC_EQC_Pois, BIC_MA_NB, BIC_EQC_NB)
  
  Estimated_para[ii, c("Pois_AR_beta1", "Pois_AR_beta2")] <- rep_AR$beta
  Estimated_para[ii, "Pois_AR_sigma2_tau"]           <- rep_AR$sigma2_tau
  Estimated_para[ii, "Pois_AR_rho"]                  <- rep_AR$rho
  
  Estimated_para[ii, c("Pois_MA_beta1", "Pois_MA_beta2")] <- rep_MA$beta
  Estimated_para[ii, "Pois_MA_sigma2_tau"]           <- rep_MA$sigma2_tau
  Estimated_para[ii, "Pois_MA_theta1"]               <- rep_MA$theta1
  
  Estimated_para[ii, c("Pois_EQC_beta1", "Pois_EQC_beta2")] <- rep_EQC$beta
  Estimated_para[ii, "Pois_EQC_sigma2_tau"]            <- rep_EQC$sigma2_tau
  
  Estimated_para[ii, c("NB_MA_beta1", "NB_MA_beta2")] <- rep_MA_NB$beta
  Estimated_para[ii, "NB_MA_sigma2_tau"]           <- rep_MA_NB$sigma2_tau
  Estimated_para[ii, "NB_MA_theta1"]               <- rep_MA_NB$theta1
  Estimated_para[ii, "NB_MA_k"]          <- rep_MA_NB$k
  
  Estimated_para[ii, c("NB_EQC_beta1", "NB_EQC_beta2")] <- rep_EQC_NB$beta
  Estimated_para[ii, "NB_EQC_sigma2_tau"]            <- rep_EQC_NB$sigma2_tau
  Estimated_para[ii, "NB_EQC_k"]          <- rep_EQC_NB$k
  
  
  best_AIC = which.min(c(AIC_AR_Pois, AIC_MA_Pois, AIC_EQC_Pois, AIC_MA_NB, AIC_EQC_NB))
  if (best_AIC == 1) Pois_AR_better_AICc  = Pois_AR_better_AICc + 1
  if (best_AIC == 2) Pois_MA_better_AICc  = Pois_MA_better_AICc + 1
  if (best_AIC == 3) Pois_EQC_better_AICc = Pois_EQC_better_AICc + 1
  if (best_AIC == 4) NB_MA_better_AICc    = NB_MA_better_AICc + 1
  if (best_AIC == 5) NB_EQC_better_AICc   = NB_EQC_better_AICc + 1
  
  best_BIC = which.min(c(BIC_AR_Pois, BIC_MA_Pois, BIC_EQC_Pois, BIC_MA_NB, BIC_EQC_NB))
  if (best_BIC == 1) Pois_AR_better_BICc  = Pois_AR_better_BICc + 1
  if (best_BIC == 2) Pois_MA_better_BICc  = Pois_MA_better_BICc + 1
  if (best_BIC == 3) Pois_EQC_better_BICc = Pois_EQC_better_BICc + 1
  if (best_BIC == 4) NB_MA_better_BICc    = NB_MA_better_BICc + 1
  if (best_BIC == 5) NB_EQC_better_BICc   = NB_EQC_better_BICc + 1
  
  ii <- ii + 1
  
}


calculate_summary <- function(estimates, true_value, parameter_name) {
  
  mean_est <- mean(estimates, na.rm = TRUE)
  bias_est <- mean_est - true_value
  sd_est   <- sd(estimates, na.rm = TRUE)
  rmse_est <- sqrt(
    mean((estimates - true_value)^2, na.rm = TRUE)
  )
  
  data.frame(
    Parameter = parameter_name,
    Mean      = round(mean_est, 3),
    Bias      = round(bias_est, 3),
    SD        = round(sd_est, 3),
    RMSE      = round(rmse_est, 3)
  )
}


Simulation_summary_beta1 <- rbind(
  calculate_summary(Estimated_para$Pois_EQC_beta1 , beta_true[1],"Pois Beta1 (EQC)"),
  calculate_summary(Estimated_para$Pois_AR_beta1, beta_true[1], "Pois Beta1 (AR1)"),
  calculate_summary(Estimated_para$Pois_MA_beta1, beta_true[1],"Pois Beta1 (MA1)"),
  calculate_summary(Estimated_para$NB_EQC_beta1, beta_true[1],"NB Beta1 (EQC)"),
  calculate_summary(Estimated_para$NB_MA_beta1, beta_true[1],"NB Beta1 (MA1)"))


Simulation_summary_beta2 <- rbind(   
  calculate_summary( Estimated_para$Pois_EQC_beta2, beta_true[2], "Pois Beta2 (EQC)"),
  calculate_summary( Estimated_para$Pois_AR_beta2, beta_true[2],"Pois Beta2 (AR1)"),
  calculate_summary( Estimated_para$Pois_MA_beta2, beta_true[2],"Pois Beta2 (MA1)"),
  calculate_summary(Estimated_para$NB_EQC_beta2, beta_true[2],"NB Beta2 (EQC)"),
  calculate_summary(Estimated_para$NB_MA_beta2, beta_true[2],"NB Beta2 (MA1)")
)


Simulation_summary_sigma2_tau <- rbind( 
  calculate_summary( Estimated_para$Pois_EQC_sigma2_tau, sigma2_tau_true,"Pois sigma2_tau (EQC)"),
  calculate_summary( Estimated_para$Pois_AR_sigma2_tau, sigma2_tau_true,"Pois sigma2_tau (AR1)"),
  calculate_summary( Estimated_para$Pois_MA_sigma2_tau, sigma2_tau_true,"Pois sigma2_tau (MA1)"),
  calculate_summary( Estimated_para$NB_EQC_sigma2_tau, sigma2_tau_true,"NB sigma2_tau (EQC)"),
  calculate_summary( Estimated_para$NB_MA_sigma2_tau, sigma2_tau_true,"NB sigma2_tau (MA1)")
)

Simulation_summary_rho <- rbind(calculate_summary( Estimated_para$Pois_AR_rho,rho_true,"Pois rho (AR1)"))

Simulation_summary_theta1 <- rbind(
  calculate_summary( Estimated_para$Pois_MA_theta1,theta1_true,"Pois theta1 (MA1)"),
  calculate_summary( Estimated_para$NB_MA_theta1,theta1_true,"NB theta1 (MA1)"))

Simulation_summary_k <- rbind(
  calculate_summary( Estimated_para$NB_EQC_k, k_true ,"NB k (EQC)"),
  calculate_summary( Estimated_para$NB_MA_k, k_true ,"NB K (MA1)"))


#**********************************
# Model Selection
#**********************************


cat("\n--- AIC comparison ---\n")
cat("Poisson EQC better     :", Pois_EQC_better_AICc, "times\n")
cat("Poisson AR(1) better   :", Pois_AR_better_AICc, "times\n")
cat("Poisson MA(1) better   :", Pois_MA_better_AICc, "times\n")
cat("Neg Bin EQC better     :", NB_EQC_better_AICc, "times\n")
cat("Neg Bin MA(1) better   :", NB_MA_better_AICc, "times\n")


cat("\n--- BIC comparison ---\n")
cat("Poisson EQC better     :", Pois_EQC_better_BICc, "times\n")
cat("Poisson AR(1) better   :", Pois_AR_better_BICc, "times\n")
cat("Poisson MA(1) better   :", Pois_MA_better_BICc, "times\n")
cat("Neg Bin EQC better     :", NB_EQC_better_BICc, "times\n")
cat("Neg Bin MA(1) better   :", NB_MA_better_BICc, "times\n")


#**********************************
# Parameter Estimation
#**********************************

cat("======================================================\n")
cat("       Parameter Estimation \n")
cat("======================================================\n")

cat("Beta1        : ", beta_true[1], "\n")
print(Simulation_summary_beta1)

cat("Beta2        : ", beta_true[2], "\n")
print(Simulation_summary_beta2)

cat("Sigma2_tau   :", sigma2_tau_true, "\n")
print(Simulation_summary_sigma2_tau)

cat("Rho          :",rho_true, "\n")
print(Simulation_summary_rho)

cat("Theta1       : ",theta1_true, "\n" )
print(Simulation_summary_theta1)

cat("k            :", k_true, "\n")
print(Simulation_summary_k)


# Total Error Counts for Each Model
cat("Total error count for Poisson AR1 :", error_count1, "\n")
cat("Total error count for Poisson MA1 :", error_count2, "\n")
cat("Total error count for Poisson EQC :", error_count3, "\n")
cat("Total error count for NB MA1      :", error_count4, "\n")
cat("Total error count for NB EQC      :", error_count5, "\n")


# Average Missing Percentage
missing_avg = mean(missing_pct)
cat("Missing percentage:", round(100*missing_avg, 2), "%\n")



