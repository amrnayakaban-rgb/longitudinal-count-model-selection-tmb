#include <TMB.hpp>

template<class Type>
Type objective_function<Type>::operator() ()
{
  //------------------------
  //--------- Data ---------
  //------------------------
  DATA_MATRIX(Y);      
  DATA_MATRIX(X1);    
  DATA_MATRIX(X2);    
  DATA_INTEGER(n);
  DATA_INTEGER(ni);
  
  //--------------------------
  //---  Parameters  ---------
  //--------------------------
  PARAMETER_VECTOR(beta); 
  PARAMETER(logit_rho);          
  PARAMETER(log_sigma2_tau);       
  PARAMETER_VECTOR(tau);          
  
  //-------------------------------
  //---  Transform parameters  ----
  //-------------------------------
  Type rho = 1 / (1 + exp(-logit_rho));   
  Type sigma2_tau = exp(log_sigma2_tau);
  Type sigma_tau  = sqrt(sigma2_tau);
  
  // ----- Negative log-likelihood -----
  Type nll = 0.0;  
  
  //---------------------------
  // Random effects
  //---------------------------
  for (int i = 0; i < n; i++) {
    nll -= dnorm(tau(i), Type(0.0), sqrt(sigma2_tau), true);
  }
  
  //---------------------------
  // Poisson AR(1) likelihood
  //---------------------------
  
  matrix<Type> mu_hat(n, ni);
  
  for (int i = 0; i < n; i++) {
    // j = 0
    Type mu_ij = exp(beta(0) * X1(i,0) + beta(1) * X2(i,0) + tau(i));
    mu_hat(i,0) = mu_ij; 
    nll -= dpois(Y(i,0), mu_ij, true);
    
    // j = 1 to ni-1
    for (int j = 1; j < ni; j++) {
      Type y_prev = Y(i,j-1);
      Type y_curr = Y(i,j);
      
      Type mu_curr = exp(beta(0) * X1(i,j) + beta(1) * X2(i,j) + tau(i)); 
      Type mu_prev = exp(beta(0) * X1(i,j-1) + beta(1) * X2(i,j-1) + tau(i));
      mu_hat(i,j) = mu_curr;
      
      Type mu_now = mu_curr - rho * mu_prev;

      
      // s_max
      Type s_max;
      
      if (y_prev < y_curr) {
        s_max = y_prev;
      } else {  
        s_max = y_curr;
      } 

      Type log_sum = Type(0.0);
      Type s = 0;
      while (s <= s_max) {
        Type lbinom = dbinom(s, y_prev, rho, true);
        Type lpois = dpois(y_curr - s, mu_now, true);

        
        if (s == 0) log_sum = lbinom + lpois;
        else log_sum = logspace_add(log_sum, lbinom + lpois);

        s += 1;
      }
      
      nll -= log_sum;
    }
  }
  
  //---------------------------
  // Reporting
  //---------------------------
  REPORT(beta);
  REPORT(rho);
  REPORT(sigma2_tau);
  REPORT(sigma_tau);
  REPORT(mu_hat);
  
  ADREPORT(beta);
  ADREPORT(rho);
  ADREPORT(sigma2_tau);
  ADREPORT(sigma_tau);
  ADREPORT(mu_hat);
  
  return nll;
}

