#include <TMB.hpp>

template<class Type>
Type objective_function<Type>::operator() ()
{
  //------------------------
  //--------- Data ---------
  //------------------------
  DATA_MATRIX(Y);      
  DATA_MATRIX(X1);    
  DATA_MATRIX(X2);  
  DATA_INTEGER(n);
  DATA_INTEGER(ni);
  
  //--------------------------
  //---  Parameters  ---------
  //--------------------------
  PARAMETER_VECTOR(beta);          
  PARAMETER(log_sigma2_tau);       
  PARAMETER_VECTOR(tau); 
  PARAMETER(log_k);         
   
  //-------------------------------
  //---  Transform parameters  ----
  //-------------------------------
   
   Type sigma2_tau = exp(log_sigma2_tau);
   Type sigma_tau  = sqrt(sigma2_tau); 
   Type k = exp(log_k); 
  

  //-------------------------------
  //---  Negative log-likelihood  -
  //-------------------------------
  
  Type nll = 0.0;  
  
  //---------------------------
  // Random effects
  //---------------------------
  
  matrix<Type> mu_hat(n, ni);
  matrix<Type> var_hat(n, ni);
  
  for (int i = 0; i < n; i++) {
    nll -= dnorm(tau(i), Type(0.0), sigma_tau, true);
  }
  
  
  for(int i=0; i<n; i++){
    for(int j = 0; j < ni; j++){
      Type mu_ij =  exp( X1(i,j)*beta(0) + X2(i,j)*beta(1) + tau(i));
      
      Type var_ij = mu_ij + ((mu_ij * mu_ij) / k) ;
      
      mu_hat(i,j) = mu_ij;
      
      var_hat(i,j) = var_ij;
      
      nll -= dnbinom2(Y(i,j),mu_ij, var_ij,true);
    }
  }
  
    
    
  
  REPORT(beta);
  REPORT(sigma2_tau);
  REPORT(sigma_tau);
  REPORT(tau);
  REPORT(mu_hat);
  REPORT(var_hat);
  REPORT(k);
  
  ADREPORT(beta);
  ADREPORT(sigma2_tau);
  ADREPORT(sigma_tau);
  ADREPORT(k);
  ADREPORT(mu_hat);
  ADREPORT(var_hat);
  
  return nll;
}
