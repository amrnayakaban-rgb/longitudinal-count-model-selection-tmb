#include <TMB.hpp>

template<class Type>
Type objective_function<Type>::operator() ()
{
  //------------------------
  //--------- Data ---------
  //------------------------
  DATA_MATRIX(Y);      
  DATA_MATRIX(X1);    
  DATA_MATRIX(X2);
  DATA_MATRIX(X3);    
  DATA_MATRIX(X4);
  DATA_MATRIX(delta); 
  DATA_INTEGER(n);
  DATA_INTEGER(ni);
  
  //--------------------------
  //---  Parameters  ---------
  //--------------------------
  PARAMETER_VECTOR(beta);          
  PARAMETER(log_sigma_tau);       
  PARAMETER_VECTOR(tau);          
   
  //-------------------------------
  //---  Transform parameters  ----
  //-------------------------------
   
   Type sigma2_tau = exp(log_sigma_tau);
   Type sigma_tau  = sqrt(sigma2_tau); 
  

  //-------------------------------
  //---  Negative log-likelihood  -
  //-------------------------------
  
  Type nll = 0.0;  
  
  //---------------------------
  // Random effects
  //---------------------------
  for (int i = 0; i < n; i++) {
    nll -= dnorm(tau(i), Type(0.0), sigma_tau, true);
  }
  
  
    for(int i = 0; i < n; i++){
        for(int j = 0; j < ni; j++){
            if(delta(i,j) == 1){ 
                Type mu_ij = exp( beta(0) 
                + X1(i,j)*beta(1) 
                + X2(i,j)*beta(2) 
                + X3(i,j)*beta(3) 
                + X4(i,j)*beta(4) 
                + tau(i));
                nll -= dpois(Y(i,j), mu_ij, true);
            }
        }
    }
  
  REPORT(beta);
  REPORT(sigma_tau);
  
  ADREPORT(beta);
  ADREPORT(sigma_tau);
  
  return nll;
}
