library(TMB)
library(MASS)
library(JM) 

compile("AR1_real_data.cpp")
dyn.load(dynlib("AR1_real_data"))

compile("MA1_real_data.cpp")
dyn.load(dynlib("MA1_real_data"))

compile("EQC_real_data.cpp")
dyn.load(dynlib("EQC_real_data"))


######################################################################
##********** Real data Analysis - AIDS data  *************************
######################################################################

sigma2_tau=0.5
time_seq = seq(0,18,2)

data(aids, package = "JM") 
Rdata = aids
Rdata$CD4N = (Rdata$CD4^2)
head(Rdata)

n = length(table(Rdata$patient))
ni = length(time_seq)


missing_pct = ((n*ni)-length(Rdata$patient))/(n*ni)
missing_pct


#***************************************
# Y ,delta and covariates
#***************************************

set.seed(100)

# Random effects
sigma_tau = sqrt(sigma2_tau)
tau = rnorm(n, mean = 0, sd = sigma_tau)  


Y = matrix(NA, nrow = n, ncol = ni)
delta = matrix(0, nrow = n, ncol = ni)

X1_gen = matrix(NA, nrow = n, ncol = ni)
X2_drug = matrix(NA, nrow = n, ncol = ni)
X3_prev = matrix(NA, nrow = n, ncol = ni)
X4_AZT = matrix(NA, nrow = n, ncol = ni)


subject_ids = seq_along(sort(unique(Rdata$patient)))

for (i in subject_ids) {
  
  sub_data  = Rdata[Rdata$patient == subject_ids[i], ]
  
  for (k in 1:nrow(sub_data)) {
    
    obs_idx    = which(time_seq == sub_data$obstime[k])
    
    Y[i,obs_idx]     = sub_data$CD4N[k]
    delta[i,obs_idx] = 1
    
    X1_gen[i,obs_idx]  = ifelse(sub_data$gender[k] == "male",    1, 0)
    X2_drug[i,obs_idx] = ifelse(sub_data$drug[k]   == "ddI",     1, 0)
    X3_prev[i,obs_idx] = ifelse(sub_data$prevOI[k] == "AIDS",    1, 0)
    X4_AZT[i,obs_idx]  = ifelse(sub_data$AZT[k]    == "failure", 1, 0)
  }
}


n_sim =1
AICc <- matrix(NA, n_sim, 3)
colnames(AICc) <- c("AIC_AR", "AIC_MA", "AIC_EQC")

BICc <- matrix(NA, n_sim, 3)
colnames(BICc) <- c("BIC_AR", "BIC_MA", "BIC_EQC")



#*****************************
# Data list for TMB
#*****************************

data = list(
  Y      = Y,
  delta  = delta,
  X1     = X1_gen,
  X2     = X2_drug,
  X3     = X3_prev,
  X4     = X4_AZT,
  n      = n,
  ni     = ni)


#=====================
#  AR(1) Model
#=====================
parameters_AR <- list(
  beta = rep(0, 5),
  logit_rho = 0,
  log_sigma_tau = 0,
  tau = rep(0, n))


error_count<-0

error_AR <- try( ( obj1 <- MakeADFun(data,parameters_AR,random = "tau",
                                     DLL="AR1_real_data",
                                     inner.control=list(maxit=50000,trace=F)) ),
                 silent=TRUE )

obj1$env$tracemgc <- FALSE

if ('try-error' %in% class(error_AR)) {
  error_count = error_count + 1
  next
}

error_AR<-try( ( opt1<-nlminb(obj1$par,obj1$fn,obj1$gr,
                              control = list(trace=10,
                                             iter.max=10000,eval.max=10000,
                                             sing.tol=1e-20)) ), silent=TRUE )

if ('try-error' %in% class(error_AR)) {
  error_count = error_count + 1
  next
}

if (opt1$convergence != 0) {
  error_count = error_count + 1
  next
}

obj1$gr(opt1$par)
rep_AR = obj1$report() 

AIC_AR <- 2*opt1$objective + 2*length(obj1$par)
BIC_AR <- 2*opt1$objective + log(length(data$Y))*length(obj1$par)


#=====================
#  MA(1) Model
#=====================
parameters_MA <- list(
  beta = rep(0,5),
  log_sigma_tau = 0,
  tau = matrix(0, nrow = n, ncol = ni),
  theta1=0)


error_MA <- try( ( obj2 <- MakeADFun(data,parameters_MA,random = "tau",
                                     DLL="MA1_real_data",
                                     inner.control=list(maxit=50000,trace=F)) ),
                 silent=TRUE )

obj2$env$tracemgc <- FALSE

if ('try-error' %in% class(error_MA)) {
  error_count = error_count + 1
  next
}

error_MA<-try( ( opt2<-nlminb(obj2$par,obj2$fn,obj2$gr,
                              control = list(trace=10,
                                             iter.max=10000,eval.max=10000,
                                             sing.tol=1e-20)) ), silent=TRUE )

if ('try-error' %in% class(error_MA)) {
  error_count = error_count + 1
  next
}

if (opt2$convergence != 0) {
  error_count = error_count + 1
  next
}

obj2$gr(opt2$par)
rep_MA = obj2$report() 

AIC_MA <- 2*opt2$objective + 2*length(obj2$par)
BIC_MA <- 2*opt2$objective + log(length(data$Y))*length(obj2$par)

#=====================
#  EQC Model
#=====================
parameters_EQC <- list(
  beta = rep(0, 5),
  log_sigma_tau = 0,
  tau = rep(0,n))


error_EQC <- try( ( obj3 <- MakeADFun(data,parameters_EQC,random = "tau",
                                      DLL="EQC_real_data",
                                      inner.control=list(maxit=50000,trace=F)) ),
                  silent=TRUE )

obj3$env$tracemgc <- FALSE

if ('try-error' %in% class(error_EQC)) {
  error_count = error_count + 1
  next
}

error_EQC <-try( ( opt3<-nlminb(obj3$par,obj3$fn,obj3$gr,
                                control = list(trace=10,
                                               iter.max=10000,eval.max=10000,
                                               sing.tol=1e-20)) ), silent=TRUE )

if ('try-error' %in% class(error_EQC)) {
  error_count = error_count + 1
  next
}

if (opt3$convergence != 0) {
  error_count = error_count + 1
  next
}

obj3$gr(opt3$par)
rep_EQC = obj3$report() 

AIC_EQC <- 2*opt3$objective + 2*length(obj3$par)
BIC_EQC <- 2*opt3$objective + log(length(data$Y))*length(obj3$par)



#*******************
#* AIC and BIC
#*******************

AICc = c(AIC_AR, AIC_MA, AIC_EQC)
BICc = c(BIC_AR, BIC_MA, BIC_EQC)

structures = c("AR1", "MA1", "EQC")

best_AIC_index = which.min(AICc)
best_BIC_index = which.min(BICc)

rep1 = sdreport(obj1)
rep2 = sdreport(obj2)
rep3 = sdreport(obj3)


#**********************
#* Coefficients and SE
#**********************


tab1 = summary(rep1)
last61 = tail(tab1, 7)
d1= data.frame(round(last61,3))
rownames(d1)=c("beta0","beta1","beta2","beta3","beta4","rho","sigma_tau")


tab2 = summary(rep2)
last62 = tail(tab2, 7)
d2= data.frame(round(last62,3))
rownames(d2)=c("beta0","beta1","beta2","beta3","beta4","sigma_tau","theta1")


tab3 = summary(rep3)
last63 = tail(tab3, 6)
d3= data.frame(round(last63,3))
rownames(d3)=c("beta0","beta1","beta2","beta3","beta4","sigma_tau")


# Results

cat("*************************************", "\n")
cat("AIC and BIC Comparison", "\n")
cat("*************************************", "\n")

for(i in seq_along(AICc)) {
  cat("Structure:", structures[i], "AIC =", AICc[i], "\n")
}


for(i in seq_along(BICc)) {
  cat("Structure:", structures[i], "BIC =", BICc[i], "\n")
}

cat("Minimum AIC model: Correlation structure with", structures[best_AIC_index], "\n")
cat("Minimum BIC model: Correlation structure with", structures[best_BIC_index], "\n")


cat("*************************************", "\n")
cat("Estimated Coefficients and SE", "\n")
cat("*************************************", "\n")

cat("Estimated coefficients with AR1 Model", "\n")
d1

cat("Estimated coefficients with MA1 Model", "\n")
d2 

cat("Estimated coefficients with EQC Model", "\n")
d3
