#include <TMB.hpp>

template<class Type>
Type objective_function<Type>::operator() ()
{
  //------------------------
  //--------- Data ---------
  //------------------------
  DATA_MATRIX(Y);      
  DATA_MATRIX(X1);    
  DATA_MATRIX(X2);
  DATA_MATRIX(X3);    
  DATA_MATRIX(X4);
  DATA_MATRIX(delta); 
  DATA_INTEGER(n);
  DATA_INTEGER(ni);
  
  //--------------------------
  //---  Parameters  ---------
  //--------------------------
  PARAMETER_VECTOR(beta);          
  PARAMETER(log_sigma_tau);       
  PARAMETER_MATRIX(tau);          
  PARAMETER(theta1); 
  
  //-------------------------------
  //---  Transform parameters  ----
  //-------------------------------
  Type sigma2_tau = exp(log_sigma_tau);
  Type sigma_tau  = sqrt(sigma2_tau); 

  //-------------------------------
  //---  Negative log-likelihood ---
  //-------------------------------
  Type nll = 0.0;  

  //-------------------------------
  //--- Random effect ------------
  //-------------------------------
  using namespace density;
  
   matrix<Type> cov_tau(ni,ni);
  
  for(int i=0; i<ni; i++){
    for(int j=0; j<ni; j++){
      if(i==j) cov_tau(i,j) = (1.0 + theta1*theta1)*sigma2_tau; 
      else if(abs(i-j)==1) cov_tau(i,j) = theta1*sigma2_tau;    
      else cov_tau(i,j)=Type(0.0);                              
    }
  }
   
  //---------------------------
  // Likelihood Function
  //---------------------------
  
  
  for(int i=0; i<n; i++){
    
    // for random effect
    vector<Type> tau_i = tau.row(i); 
    
    nll += MVNORM(cov_tau)(tau_i);      
    
    
    //for observed data

     for(int j = 0; j < ni; j++){
            if(delta(i,j) == 1){ 
                Type mu_ij =  exp( beta(0) + X1(i,j)*beta(1) + X2(i,j)*beta(2) + 
                X3(i,j)*beta(3) + 
                X4(i,j)*beta(4) +  tau(i,j));
                nll -= dpois(Y(i,j), mu_ij, true);
             }
         }
  }
  
  
  //-------------------------------
  //---  Reports
  //-------------------------------
  REPORT(beta);
  REPORT(sigma_tau);
  REPORT(theta1);
  
  ADREPORT(beta);
  ADREPORT(sigma_tau);
  ADREPORT(theta1);
  
  return nll;
} 
