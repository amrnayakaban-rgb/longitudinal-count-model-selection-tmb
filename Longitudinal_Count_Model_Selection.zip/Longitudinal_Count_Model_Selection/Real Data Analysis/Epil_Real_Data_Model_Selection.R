library(TMB)
library(MASS)

compile("Poisson_AR1_Epil_Data.cpp")
dyn.load(dynlib("Poisson_AR1_Epil_Data"))

compile("Poisson_MA1_Epil_Data.cpp")
dyn.load(dynlib("Poisson_MA1_Epil_Data"))

compile("Poisson_EQC_Epil_Data.cpp")
dyn.load(dynlib("Poisson_EQC_Epil_Data"))

compile("NB_MA1_Epil_Data.cpp")
dyn.load(dynlib("NB_MA1_Epil_Data"))

compile("NB_EQC_Epil_Data.cpp")
dyn.load(dynlib("NB_EQC_Epil_Data"))

data(epil)
Rdata <- epil

Rdata <- subset(Rdata, subject != 49)
Rdata <- Rdata[order(Rdata$subject, Rdata$period), ]
subject_ids <- sort(unique(Rdata$subject))

n  <- length(subject_ids)
ni <- 4

Y            <- matrix(NA, n, ni)
X1_base       <- matrix(NA, n, ni)
X2_age        <- matrix(NA, n, ni)
X3_trt        <- matrix(NA, n, ni)
X4_visit4     <- matrix(NA, n, ni)
X5_trt_base   <- matrix(NA, n, ni)

for (i in seq_along(subject_ids)) {
  
  sub_data <- Rdata[Rdata$subject == subject_ids[i], ]
  sub_data <- sub_data[order(sub_data$period), ]
  
  base_i <- log(sub_data$base[1]/ 4)
  age_i  <- log(sub_data$age[1])
  trt_i <- as.numeric(as.character(sub_data$trt[1]) == "progabide")
  
  Y[i, ] <- sub_data$y
  X1_base[i, ] <- rep(base_i, ni)
  X2_age[i, ] <- rep(age_i, ni)
  X3_trt[i, ] <- rep(trt_i, ni)
  X4_visit4[i, ] <- as.numeric(sub_data$period == 4)
  X5_trt_base[i, ] <- trt_i*base_i
}

#*****************************
# Data list for TMB
#*****************************

data <- list(
  Y           = Y,
  X1          = X1_base,
  X2          = X2_age,
  X3          = X3_trt,
  X4          = X4_visit4,
  X5          = X5_trt_base,
  n           = n,
  ni          = ni)


#**********************************
# Simulation Study
#**********************************

n_sim = 1

AICc <- matrix(NA, n_sim, 5)
colnames(AICc) <- c("AIC_AR_Pois", "AIC_MA_Pois", "AIC_EQC_Pois", "AIC_MA_NB", "AIC_EQC_NB")

BICc <- matrix(NA, n_sim, 5)
colnames(BICc) <- c("BIC_AR_Pois", "BIC_MA_Pois", "BIC_EQC_Pois", "BIC_MA_NB", "BIC_EQC_NB")

NLLc <- matrix(NA, n_sim, 5)
colnames(NLLc) <- c("nll_AR_Pois", "nll_MA_Pois", "nll_EQC_Pois", "nll__MA_NB", "nll_EQC_NB")

Pois_AR_better_AICc<-0
Pois_MA_better_AICc<-0
Pois_EQC_better_AICc<-0

Pois_AR_better_BICc<-0
Pois_MA_better_BICc<-0
Pois_EQC_better_BICc<-0

NB_MA_better_AICc<-0
NB_EQC_better_AICc<-0

NB_MA_better_BICc<-0
NB_EQC_better_BICc<-0

error_count1 <-0
error_count2 <-0
error_count3 <-0
error_count4 <-0
error_count5 <-0


ii=1
  
  #=====================
  #  Poisson AR(1) Model
  #=====================
  parameters_AR <- list(
    beta = rep(0,6),
    logit_rho = 0,
    log_sigma2_tau = 0,
    tau = rep(0, n))
  
  
  error_AR <- try( ( obj1 <- MakeADFun(data,parameters_AR,random = "tau",
                                       DLL="Poisson_AR1_Epil_Data",
                                       inner.control=list(maxit=50000,trace=F)) ),
                   silent=TRUE )
  
  obj1$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_AR)) {
    error_count1 = error_count1 + 1
    next
  }
  
  error_AR<-try( ( opt1<-nlminb(obj1$par,obj1$fn,obj1$gr,
                                control = list(trace=10,
                                               iter.max=10000,eval.max=10000,
                                               sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_AR)) {
    error_count1 = error_count1 + 1
    next
  }
  
  if (opt1$convergence != 0) {
    error_count1 = error_count1 + 1
    next
  }
  
  obj1$gr(opt1$par)
  rep_AR = obj1$report() 
  
  NLL_AR_Pois  <- opt1$objective
  
  AIC_AR_Pois <- 2*opt1$objective + 2*length(obj1$par)
  BIC_AR_Pois <- 2*opt1$objective + log(length(data$Y))*length(obj1$par)

  
  #=====================
  #  Poisson MA(1) Model
  #=====================
  parameters_MA <- list(
    beta = rep(0,6),
    log_sigma2_tau = 0,
    tau = matrix(0, nrow = n, ncol = ni),
    logit_theta1=0)
  
  
  error_MA <- try( ( obj2 <- MakeADFun(data,parameters_MA,random = "tau",
                                       DLL="Poisson_MA1_Epil_Data",
                                       inner.control=list(maxit=50000,trace=F)) ),
                   silent=TRUE )
  
  obj2$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_MA)) {
    error_count2 = error_count2 + 1
    next
  }
  
  error_MA<-try( ( opt2<-nlminb(obj2$par,obj2$fn,obj2$gr,
                                control = list(trace=10,
                                               iter.max=10000,eval.max=10000,
                                               sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_MA)) {
    error_count2 = error_count2 + 1
    next
  }
  
  if (opt2$convergence != 0) {
    error_count2 = error_count2 + 1
    next
  }
  
  obj2$gr(opt2$par)
  rep_MA = obj2$report() 
  
  NLL_MA_Pois  <- opt2$objective
  
  AIC_MA_Pois <- 2*opt2$objective + 2*length(obj2$par)
  BIC_MA_Pois <- 2*opt2$objective + log(length(data$Y))*length(obj2$par)

  
  #=====================
  #  Poisson EQC Model
  #=====================
  parameters_EQC <- list(
    beta = rep(0,6),
    log_sigma2_tau = 0,
    tau = rep(0,n))
  
  
  error_EQC <- try( ( obj3 <- MakeADFun(data,parameters_EQC,random = "tau",
                                        DLL="Poisson_EQC_Epil_Data",
                                        inner.control=list(maxit=50000,trace=F)) ),
                    silent=TRUE )
  
  obj3$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_EQC)) {
    error_count3 = error_count3 + 1
    next
  }
  
  error_EQC <-try( ( opt3<-nlminb(obj3$par,obj3$fn,obj3$gr,
                                  control = list(trace=10,
                                                 iter.max=10000,eval.max=10000,
                                                 sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_EQC)) {
    error_count3 = error_count3 + 1
    next
  }
  
  if (opt3$convergence != 0) {
    error_count3 = error_count3 + 1
    next
  }
  
  obj3$gr(opt3$par)
  rep_EQC = obj3$report() 
  
  NLL_EQC_Pois  <- opt3$objective
  
  AIC_EQC_Pois <- 2*opt3$objective + 2*length(obj3$par)
  BIC_EQC_Pois <- 2*opt3$objective + log(length(data$Y))*length(obj3$par)

  
  #=====================
  #  NB MA(1) Model
  #=====================
  parameters_MA_NB <- list(
    beta = rep(0,6),
    log_sigma2_tau = 0,
    tau = matrix(0, nrow = n, ncol = ni),
    logit_theta1=0,
    log_k = 0)
  
  
  error_MA_NB <- try( ( obj4 <- MakeADFun(data,parameters_MA_NB,random = "tau",
                                          DLL="NB_MA1_Epil_Data",
                                          inner.control=list(maxit=50000,trace=F)) ),
                      silent=TRUE )
  
  obj4$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_MA_NB)) {
    error_count4 = error_count4 + 1
    next
  }
  
  error_MA_NB <-try( ( opt4 <-nlminb(obj4$par,obj4$fn,obj4$gr,
                                     control = list(trace=10,
                                                    iter.max=10000,eval.max=10000,
                                                    sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_MA_NB)) {
    error_count4 = error_count4 + 1
    next
  }
  
  if (opt4$convergence != 0) {
    error_count4 = error_count4 + 1
    next
  }
  
  obj4$gr(opt4$par)
  rep_MA_NB = obj4$report() 
  
  NLL_MA_NB  <- opt4$objective
  
  AIC_MA_NB <- 2*opt4$objective + 2*length(obj4$par)
  BIC_MA_NB <- 2*opt4$objective + log(length(data$Y))*length(obj4$par)
  
  #=====================
  #  NB EQC Model
  #=====================
  parameters_EQC_NB <- list(
    beta = rep(0,6),
    log_sigma2_tau = 0,
    tau = rep(0,n),
    log_k = 0)
  
  
  error_EQC_NB <- try( ( obj5 <- MakeADFun(data,parameters_EQC_NB,random = "tau",
                                           DLL="NB_EQC_Epil_Data",
                                           inner.control=list(maxit=50000,trace=F)) ),
                       silent=TRUE )
  
  obj5$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_EQC_NB)) {
    error_count5 = error_count5 + 1
    next
  }
  
  error_EQC_NB <-try( ( opt5<-nlminb(obj5$par,obj5$fn,obj5$gr,
                                     control = list(trace=10,
                                                    iter.max=10000,eval.max=10000,
                                                    sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_EQC_NB)) {
    error_count5 = error_count5 + 1
    next
  }
  
  if (opt5$convergence != 0) {
    error_count5 = error_count5 + 1
    next
  }
  
  obj5$gr(opt5$par)
  rep_EQC_NB = obj5$report() 
  
  NLL_EQC_NB  <- opt5$objective
  
  AIC_EQC_NB <- 2*opt5$objective + 2*length(obj5$par)
  BIC_EQC_NB <- 2*opt5$objective + log(length(data$Y))*length(obj5$par)
  
  #---------------------
  # Results
  #---------------------
  
  AICc[ii, ] <- c(AIC_AR_Pois, AIC_MA_Pois, AIC_EQC_Pois, AIC_MA_NB , AIC_EQC_NB)
  BICc[ii, ] <- c(BIC_AR_Pois, BIC_MA_Pois, BIC_EQC_Pois, BIC_MA_NB, BIC_EQC_NB)
  NLLc[ii, ] <- c(NLL_AR_Pois, NLL_MA_Pois, NLL_EQC_Pois, NLL_MA_NB, NLL_EQC_NB)
 
  best_AIC = which.min(c(AIC_AR_Pois, AIC_MA_Pois, AIC_EQC_Pois, AIC_MA_NB, AIC_EQC_NB))
  if (best_AIC == 1) Pois_AR_better_AICc  = Pois_AR_better_AICc + 1
  if (best_AIC == 2) Pois_MA_better_AICc  = Pois_MA_better_AICc + 1
  if (best_AIC == 3) Pois_EQC_better_AICc = Pois_EQC_better_AICc + 1
  if (best_AIC == 4) NB_MA_better_AICc    = NB_MA_better_AICc + 1
  if (best_AIC == 5) NB_EQC_better_AICc   = NB_EQC_better_AICc + 1
  
  best_BIC = which.min(c(BIC_AR_Pois, BIC_MA_Pois, BIC_EQC_Pois, BIC_MA_NB, BIC_EQC_NB))
  if (best_BIC == 1) Pois_AR_better_BICc  = Pois_AR_better_BICc + 1
  if (best_BIC == 2) Pois_MA_better_BICc  = Pois_MA_better_BICc + 1
  if (best_BIC == 3) Pois_EQC_better_BICc = Pois_EQC_better_BICc + 1
  if (best_BIC == 4) NB_MA_better_BICc    = NB_MA_better_BICc + 1
  if (best_BIC == 5) NB_EQC_better_BICc   = NB_EQC_better_BICc + 1
  

  #**********************************
  # Model Selection
  #**********************************
  
  cat("\n--- AIC comparison ---\n")
  cat("Poisson AR(1) better   :", Pois_AR_better_AICc, "times\n")
  cat("Poisson MA(1) better   :", Pois_MA_better_AICc, "times\n")
  cat("Poisson EQC better     :", Pois_EQC_better_AICc, "times\n")
  cat("Neg Bin MA(1) better   :", NB_MA_better_AICc, "times\n")
  cat("Neg Bin EQC better     :", NB_EQC_better_AICc, "times\n")
  
  cat("\n--- BIC comparison ---\n")
  cat("Poisson AR(1) better   :", Pois_AR_better_BICc, "times\n")
  cat("Poisson MA(1) better   :", Pois_MA_better_BICc, "times\n")
  cat("Poisson EQC better     :", Pois_EQC_better_BICc, "times\n")
  cat("Neg Bin MA(1) better   :", NB_MA_better_BICc, "times\n")
  cat("Neg Bin EQC better     :", NB_EQC_better_BICc, "times\n")
  
  
  data_AIC_BIC <- data.frame(
  Model = c("Pois_EQC", "Pois_AR1", "Pois_MA1", "NB_EQC", "NB_MA1"),
  AIC = c(AIC_EQC_Pois,AIC_AR_Pois,AIC_MA_Pois,AIC_EQC_NB,AIC_MA_NB),
  BIC = c(BIC_EQC_Pois,BIC_AR_Pois,BIC_MA_Pois,BIC_EQC_NB,BIC_MA_NB),
  NLL = c(NLL_EQC_Pois,NLL_AR_Pois,NLL_MA_Pois,NLL_EQC_NB,NLL_MA_NB))
  
  data_AIC_BIC



