library(TMB)
library(MASS)

compile("Poisson_AR1_Epil_Data.cpp")
dyn.load(dynlib("Poisson_AR1_Epil_Data"))


data(epil)
Rdata <- epil

Rdata <- subset(Rdata, subject != 49)
Rdata <- Rdata[order(Rdata$subject, Rdata$period), ]
subject_ids <- sort(unique(Rdata$subject))

n  <- length(subject_ids)
ni <- 4

Y            <- matrix(NA, n, ni)
X1_base       <- matrix(NA, n, ni)
X2_age        <- matrix(NA, n, ni)
X3_trt        <- matrix(NA, n, ni)
X4_visit4     <- matrix(NA, n, ni)
X5_trt_base   <- matrix(NA, n, ni)

for (i in seq_along(subject_ids)) {
  
  sub_data <- Rdata[Rdata$subject == subject_ids[i], ]
  sub_data <- sub_data[order(sub_data$period), ]
  
  base_i <- log(sub_data$base[1]/ 4)
  age_i  <- log(sub_data$age[1])
  trt_i <- as.numeric(as.character(sub_data$trt[1]) == "progabide")
  
  Y[i, ] <- sub_data$y
  X1_base[i, ] <- rep(base_i, ni)
  X2_age[i, ] <- rep(age_i, ni)
  X3_trt[i, ] <- rep(trt_i, ni)
  X4_visit4[i, ] <- as.numeric(sub_data$period == 4)
  X5_trt_base[i, ] <- trt_i*base_i
}

#*****************************
# Data list for TMB
#*****************************

data <- list(
  Y           = Y,
  X1          = X1_base,
  X2          = X2_age,
  X3          = X3_trt,
  X4          = X4_visit4,
  X5          = X5_trt_base,
  n           = n,
  ni          = ni)


error_count1 <-0


#=====================
#  Poisson AR(1) Model
#=====================
parameters_AR <- list(
  beta = rep(0,6),
  logit_rho = 0,
  log_sigma2_tau = 0,
  tau = rep(0, n))


error_AR <- try( ( obj1 <- MakeADFun(data,parameters_AR,random = "tau",
                                     DLL="Poisson_AR1_Epil_Data",
                                     inner.control=list(maxit=50000,trace=F)) ),
                 silent=TRUE )

obj1$env$tracemgc <- FALSE

if ('try-error' %in% class(error_AR)) {
  error_count1 = error_count1 + 1
  next
}

error_AR<-try( ( opt1<-nlminb(obj1$par,obj1$fn,obj1$gr,
                              control = list(trace=10,
                                             iter.max=10000,eval.max=10000,
                                             sing.tol=1e-20)) ), silent=TRUE )

if ('try-error' %in% class(error_AR)) {
  error_count1 = error_count1 + 1
  next
}

if (opt1$convergence != 0) {
  error_count1 = error_count1 + 1
  next
}

obj1$gr(opt1$par)
rep_AR = obj1$report() 

AIC_AR_Pois <- 2*opt1$objective + 2*length(obj1$par)
BIC_AR_Pois <- 2*opt1$objective + log(length(data$Y))*length(obj1$par)

#**********************************
# Parameter Estimation
#**********************************

AR1_report <- obj1$report()
beta_hat_AR1 <- as.numeric(AR1_report$beta)
rho_AR1 <- as.numeric(AR1_report$rho)
sigma2_tau_AR1 <- as.numeric(AR1_report$sigma2_tau)
mu_hat_AR1 <- as.matrix(AR1_report$mu_hat)
K_AR1 <- as.numeric(AR1_report$k)

AR1_beta0 <- beta_hat_AR1[1]
AR1_beta1 <- beta_hat_AR1[2]
AR1_beta2 <- beta_hat_AR1[3]
AR1_beta3 <- beta_hat_AR1[4]
AR1_beta4 <- beta_hat_AR1[5]
AR1_beta5 <- beta_hat_AR1[6]
AR1_rho <- rho_AR1
AR1_sigma2_tau  <- sigma2_tau_AR1



AR1_estimates <- data.frame(
  Parameter = c( "beta0", "beta1", "beta2", "beta3","beta4", "beta5", "sigma2_tau", "rho"),
  Estimate = c(AR1_beta0 , AR1_beta1, AR1_beta2, AR1_beta3,AR1_beta4,AR1_beta5,
               AR1_sigma2_tau, AR1_rho))

AR1_estimates$Estimate <- round(AR1_estimates$Estimate,3)

cat("Parameter Estimation: Poisson AR(1) Model\n")
AR1_estimates

#----------
## With SE 
#----------

rep1 = sdreport(obj1)

rep1_summary <- round(summary(rep1), 3)
AR1_estimates_SE <- tail(rep1_summary,9)
rownames(AR1_estimates_SE) <- c("beta0", "beta1", "beta2", "beta3", "beta4", "beta5","rho",
                                 "sigma2_tau", "sigma_tau") 

cat("Parameter Estimation: Poisson AR1 Model with SE \n")
AR1_estimates_SE


#*************************************
#* Randomized Quantile Residuals
#*************************************

set.seed(10)

AR1_residual <- matrix( NA,nrow = n, ncol = ni)

for (i in 1:n) {
  for (j in 1:ni) {
    
    current_y  <- Y[i,j]
    current_mu <- mu_hat_AR1[i,j]
    
    lower <- ppois( q  = current_y - 1,lambda = current_mu )
    upper <- ppois( q  = current_y, lambda = current_mu)
    
    u <- runif(n = 1,min = lower, max = upper)
    
    AR1_residual[i,j] <- qnorm(u)
  }
}

res_AR1 <- AR1_residual[!is.na(AR1_residual)]
res_AR1 <- as.vector(res_AR1)

# Normal Q-Q plot
qqnorm(res_AR1, pch = 16,cex = 0.6, main = "Normal Q-Q Plot: AR(1) Model")
qqline(res_AR1,col = "red", lwd = 2)

hist(res_AR1)

# Kolmogorov-Smirnov test
KS_AR1 <- ks.test( res_AR1, "pnorm", mean = 0, sd = 1,exact = FALSE)
KS_AR1


