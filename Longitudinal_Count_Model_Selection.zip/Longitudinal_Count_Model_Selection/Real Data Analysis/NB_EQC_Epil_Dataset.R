library(TMB)
library(MASS)

compile("NB_EQC_Epil_Data.cpp")
dyn.load(dynlib("NB_EQC_Epil_Data"))


data(epil)
Rdata <- epil

Rdata <- subset(Rdata, subject != 49)
Rdata <- Rdata[order(Rdata$subject, Rdata$period), ]
subject_ids <- sort(unique(Rdata$subject))

n  <- length(subject_ids)
ni <- 4

Y            <- matrix(NA, n, ni)
X1_base       <- matrix(NA, n, ni)
X2_age        <- matrix(NA, n, ni)
X3_trt        <- matrix(NA, n, ni)
X4_visit4     <- matrix(NA, n, ni)
X5_trt_base   <- matrix(NA, n, ni)

for (i in seq_along(subject_ids)) {
  
  sub_data <- Rdata[Rdata$subject == subject_ids[i], ]
  sub_data <- sub_data[order(sub_data$period), ]
  
  base_i <- log(sub_data$base[1]/ 4)
  age_i  <- log(sub_data$age[1])
  trt_i <- as.numeric(as.character(sub_data$trt[1]) == "progabide")
  
  Y[i, ] <- sub_data$y
  X1_base[i, ] <- rep(base_i, ni)
  X2_age[i, ] <- rep(age_i, ni)
  X3_trt[i, ] <- rep(trt_i, ni)
  X4_visit4[i, ] <- as.numeric(sub_data$period == 4)
  X5_trt_base[i, ] <- trt_i*base_i
}

#*****************************
# Data list for TMB
#*****************************

data <- list(
  Y           = Y,
  X1          = X1_base,
  X2          = X2_age,
  X3          = X3_trt,
  X4          = X4_visit4,
  X5          = X5_trt_base,
  n           = n,
  ni          = ni)


error_count5 <-0

#=====================
#  NB EQC Model
#=====================
parameters_EQC_NB <- list(
  beta = rep(0,6),
  log_sigma2_tau = 0,
  tau = rep(0,n),
  log_k = 0)


error_EQC_NB <- try( ( obj5 <- MakeADFun(data,parameters_EQC_NB,random = "tau",
                                         DLL="NB_EQC_Epil_Data",
                                         inner.control=list(maxit=50000,trace=F)) ),
                     silent=TRUE )

obj5$env$tracemgc <- FALSE

if ('try-error' %in% class(error_EQC_NB)) {
  error_count5 = error_count5 + 1
  next
}

error_EQC_NB <-try( ( opt5<-nlminb(obj5$par,obj5$fn,obj5$gr,
                                   control = list(trace=10,
                                                  iter.max=10000,eval.max=10000,
                                                  sing.tol=1e-20)) ), silent=TRUE )

if ('try-error' %in% class(error_EQC_NB)) {
  error_count5 = error_count5 + 1
  next
}

if (opt5$convergence != 0) {
  error_count5 = error_count5 + 1
  next
}

obj5$gr(opt5$par)
rep_EQC_NB = obj5$report() 

AIC_EQC_NB <- 2*opt5$objective + 2*length(obj5$par)
BIC_EQC_NB <- 2*opt5$objective + log(length(data$Y))*length(obj5$par)

#**********************************
# Parameter Estimation
#**********************************

NB_EQC_report <- obj5$report()
beta_hat_NB_EQC <- as.numeric(NB_EQC_report$beta)
sigma2_tau_NB_EQC <- as.numeric(NB_EQC_report$sigma2_tau)
theta1_NB_EQC <- as.numeric(NB_EQC_report$theta1)
k_NB_EQC <- as.numeric(NB_EQC_report$k)
mu_hat_NB_EQC <- as.matrix(NB_EQC_report$mu_hat)

EQC_beta0 <- beta_hat_NB_EQC[1]
EQC_beta1 <- beta_hat_NB_EQC[2]
EQC_beta2 <- beta_hat_NB_EQC[3]
EQC_beta3 <- beta_hat_NB_EQC[4]
EQC_beta4 <- beta_hat_NB_EQC[5]
EQC_beta5 <- beta_hat_NB_EQC[6]
EQC_sigma2_tau  <- sigma2_tau_NB_EQC
EQC_k <- k_NB_EQC


NB_EQC_estimates <- data.frame(
  Parameter = c( "beta0","beta1", "beta2", "beta3","beta4", "beta5", "sigma2_tau", "k"),
  Estimate = c( EQC_beta0, EQC_beta1, EQC_beta2, EQC_beta3,EQC_beta4, EQC_beta5,
                EQC_sigma2_tau, EQC_k))

NB_EQC_estimates$Estimate = round(NB_EQC_estimates$Estimate,3)

cat("Parameter Estimation: NB EQC Model\n")
NB_EQC_estimates


#----------
## With SE 
#----------

rep5 = sdreport(obj5)

rep5_summary <- round(summary(rep5), 3)
NB_EQC_estimates_SE <- tail(rep5_summary,9)
rownames(NB_EQC_estimates_SE) <- c("beta0", "beta1", "beta2", "beta3", "beta4", "beta5",
                                 "sigma2_tau", "sigma_tau", "k") 

cat("Parameter Estimation: NB EQC Model with SE \n")
NB_EQC_estimates_SE


#*************************************
#* Randomized Quantile Residuals
#*************************************

set.seed(10)

NB_EQC_residual <- matrix( NA,nrow = n, ncol = ni)

for (i in 1:n) {
  for (j in 1:ni) {
    
    current_y  <- Y[i,j]
    current_mu <- mu_hat_NB_EQC[i,j]
    
    lower <- pnbinom( q    = current_y - 1, size = k_NB_EQC,  mu   = current_mu )
    upper <- pnbinom( q    = current_y, size = k_NB_EQC, mu   = current_mu)
    
    u <- runif(n = 1,min = lower, max = upper)
    
    NB_EQC_residual[i,j] <- qnorm(u)
  }
}

res_NB_EQC <- NB_EQC_residual[!is.na(NB_EQC_residual)]
res_NB_EQC <- as.vector(res_NB_EQC)

# Normal Q-Q plot
qqnorm(res_NB_EQC, pch = 16,cex = 0.6, main = "Q-Q Plot: NB EQC Model")
qqline(res_NB_EQC,col = "red", lwd = 2)

hist(res_NB_EQC)

# Kolmogorov-Smirnov test
KS_NB_EQC <- ks.test( res_NB_EQC, "pnorm", mean = 0, sd = 1,exact = FALSE)
KS_NB_EQC
