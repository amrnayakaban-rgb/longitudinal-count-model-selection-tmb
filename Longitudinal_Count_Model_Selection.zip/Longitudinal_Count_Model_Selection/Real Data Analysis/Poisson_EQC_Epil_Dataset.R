library(TMB)
library(MASS)

compile("Poisson_EQC_Epil_Data.cpp")
dyn.load(dynlib("Poisson_EQC_Epil_Data"))


data(epil)
Rdata <- epil

Rdata <- subset(Rdata, subject != 49)
Rdata <- Rdata[order(Rdata$subject, Rdata$period), ]
subject_ids <- sort(unique(Rdata$subject))

n  <- length(subject_ids)
ni <- 4

Y            <- matrix(NA, n, ni)
X1_base       <- matrix(NA, n, ni)
X2_age        <- matrix(NA, n, ni)
X3_trt        <- matrix(NA, n, ni)
X4_visit4     <- matrix(NA, n, ni)
X5_trt_base   <- matrix(NA, n, ni)

for (i in seq_along(subject_ids)) {
  
  sub_data <- Rdata[Rdata$subject == subject_ids[i], ]
  sub_data <- sub_data[order(sub_data$period), ]
  
  base_i <- log(sub_data$base[1]/ 4)
  age_i  <- log(sub_data$age[1])
  trt_i <- as.numeric(as.character(sub_data$trt[1]) == "progabide")
  
  Y[i, ] <- sub_data$y
  X1_base[i, ] <- rep(base_i, ni)
  X2_age[i, ] <- rep(age_i, ni)
  X3_trt[i, ] <- rep(trt_i, ni)
  X4_visit4[i, ] <- as.numeric(sub_data$period == 4)
  X5_trt_base[i, ] <- trt_i*base_i
}

#*****************************
# Data list for TMB
#*****************************

data <- list(
  Y           = Y,
  X1          = X1_base,
  X2          = X2_age,
  X3          = X3_trt,
  X4          = X4_visit4,
  X5          = X5_trt_base,
  n           = n,
  ni          = ni)


error_count3 <-0


#=====================
#  Poisson EQC Model
#=====================
parameters_EQC <- list(
  beta = rep(0,6),
  log_sigma2_tau = 0,
  tau = rep(0,n))


error_EQC <- try( ( obj3 <- MakeADFun(data,parameters_EQC,random = "tau",
                                      DLL="Poisson_EQC_Epil_Data",
                                      inner.control=list(maxit=50000,trace=F)) ),
                  silent=TRUE )

obj3$env$tracemgc <- FALSE

if ('try-error' %in% class(error_EQC)) {
  error_count3 = error_count3 + 1
  next
}

error_EQC <-try( ( opt3<-nlminb(obj3$par,obj3$fn,obj3$gr,
                                control = list(trace=10,
                                               iter.max=10000,eval.max=10000,
                                               sing.tol=1e-20)) ), silent=TRUE )

if ('try-error' %in% class(error_EQC)) {
  error_count3 = error_count3 + 1
  next
}

if (opt3$convergence != 0) {
  error_count3 = error_count3 + 1
  next
}

obj3$gr(opt3$par)
rep_EQC = obj3$report() 

AIC_EQC_Pois <- 2*opt3$objective + 2*length(obj3$par)
BIC_EQC_Pois <- 2*opt3$objective + log(length(data$Y))*length(obj3$par)

#**********************************
# Parameter Estimation
#**********************************

EQC_report <- obj3$report()
beta_hat_EQC <- as.numeric(EQC_report$beta)
sigma2_tau_EQC <- as.numeric(EQC_report$sigma2_tau)
mu_hat_EQC <- as.matrix(EQC_report$mu_hat)

EQC_beta0 <- beta_hat_EQC[1]
EQC_beta1 <- beta_hat_EQC[2]
EQC_beta2 <- beta_hat_EQC[3]
EQC_beta3 <- beta_hat_EQC[4]
EQC_beta4 <- beta_hat_EQC[5]
EQC_beta5 <- beta_hat_EQC[6]
EQC_sigma2_tau  <- sigma2_tau_EQC

EQC_estimates <- data.frame(
  Parameter = c( "beta0","beta1", "beta2", "beta3","beta4","beta5","sigma2_tau"),
  Estimate = c( EQC_beta0,EQC_beta1, EQC_beta2, EQC_beta3,EQC_beta4, EQC_beta5,
                EQC_sigma2_tau ))

EQC_estimates$Estimate <- round(EQC_estimates$Estimate,3)

cat("Parameter Estimation: Poisson EQC Model\n")
EQC_estimates

#----------
## With SE 
#----------

rep3 = sdreport(obj3)

rep3_summary <- round(summary(rep3), 3)
EQC_estimates_SE <- tail(rep3_summary,8)
rownames(EQC_estimates_SE ) <- c("beta0", "beta1", "beta2", "beta3", "beta4", "beta5",
                         "sigma2_tau", "sigma_tau") 

cat("Parameter Estimation: Poisson EQC Model with SE \n")
EQC_estimates_SE


#*************************************
#* Randomized Quantile Residuals
#*************************************

set.seed(10)

EQC_residual <- matrix( NA,nrow = n, ncol = ni)

for (i in 1:n) {
  for (j in 1:ni) {
    
    current_y  <- Y[i,j]
    current_mu <- mu_hat_EQC[i,j]
    
    lower <- ppois( q  = current_y - 1,lambda = current_mu )
    upper <- ppois( q  = current_y, lambda = current_mu)
    
    u <- runif(n = 1,min = lower, max = upper)
    
    EQC_residual[i,j] <- qnorm(u)
  }
}

res_EQC <- EQC_residual[!is.na(EQC_residual)]
res_EQC <- as.vector(res_EQC)

# Normal Q-Q plot
qqnorm(res_EQC, pch = 16,cex = 0.6, main = "Normal Q-Q Plot: EQC Model")
qqline(res_EQC,col = "red", lwd = 2)

hist(res_EQC)

# Kolmogorov-Smirnov test
KS_EQC <- ks.test( res_EQC, "pnorm", mean = 0, sd = 1,exact = FALSE)
KS_EQC


