library(TMB)
library(MASS)

compile("Poisson_MA1_Epil_Data.cpp")
dyn.load(dynlib("Poisson_MA1_Epil_Data"))


data(epil)
Rdata <- epil

Rdata <- subset(Rdata, subject != 49)
Rdata <- Rdata[order(Rdata$subject, Rdata$period), ]
subject_ids <- sort(unique(Rdata$subject))

n  <- length(subject_ids)
ni <- 4

Y            <- matrix(NA, n, ni)
X1_base       <- matrix(NA, n, ni)
X2_age        <- matrix(NA, n, ni)
X3_trt        <- matrix(NA, n, ni)
X4_visit4     <- matrix(NA, n, ni)
X5_trt_base   <- matrix(NA, n, ni)

for (i in seq_along(subject_ids)) {
  
  sub_data <- Rdata[Rdata$subject == subject_ids[i], ]
  sub_data <- sub_data[order(sub_data$period), ]
  
  base_i <- log(sub_data$base[1]/ 4)
  age_i  <- log(sub_data$age[1])
  trt_i <- as.numeric(as.character(sub_data$trt[1]) == "progabide")
  
  Y[i, ] <- sub_data$y
  X1_base[i, ] <- rep(base_i, ni)
  X2_age[i, ] <- rep(age_i, ni)
  X3_trt[i, ] <- rep(trt_i, ni)
  X4_visit4[i, ] <- as.numeric(sub_data$period == 4)
  X5_trt_base[i, ] <- trt_i*base_i
}

#*****************************
# Data list for TMB
#*****************************

data <- list(
  Y           = Y,
  X1          = X1_base,
  X2          = X2_age,
  X3          = X3_trt,
  X4          = X4_visit4,
  X5          = X5_trt_base,
  n           = n,
  ni          = ni)


error_count2 <-0

#=====================
#  Poisson MA(1) Model
#=====================
parameters_MA <- list(
  beta = rep(0,6),
  log_sigma2_tau = 0,
  tau = matrix(0, nrow = n, ncol = ni),
  logit_theta1=0)


error_MA <- try( ( obj2 <- MakeADFun(data,parameters_MA,random = "tau",
                                     DLL="Poisson_MA1_Epil_Data",
                                     inner.control=list(maxit=50000,trace=F)) ),
                 silent=TRUE )

obj2$env$tracemgc <- FALSE

if ('try-error' %in% class(error_MA)) {
  error_count2 = error_count2 + 1
  next
}

error_MA<-try( ( opt2<-nlminb(obj2$par,obj2$fn,obj2$gr,
                              control = list(trace=10,
                                             iter.max=10000,eval.max=10000,
                                             sing.tol=1e-20)) ), silent=TRUE )

if ('try-error' %in% class(error_MA)) {
  error_count2 = error_count2 + 1
  next
}

if (opt2$convergence != 0) {
  error_count2 = error_count2 + 1
  next
}

obj2$gr(opt2$par)
rep_MA = obj2$report() 

AIC_MA_Pois <- 2*opt2$objective + 2*length(obj2$par)
BIC_MA_Pois <- 2*opt2$objective + log(length(data$Y))*length(obj2$par)

#**********************************
# Parameter Estimation
#**********************************

MA1_report <- obj2$report()
beta_hat_MA1 <- as.numeric(MA1_report$beta)
sigma2_tau_MA1 <- as.numeric(MA1_report$sigma2_tau)
theta1_MA1 <- as.numeric(MA1_report$theta1)
mu_hat_MA1 <- as.matrix(MA1_report$mu_hat)

MA1_beta0 <- beta_hat_MA1[1]
MA1_beta1 <- beta_hat_MA1[2]
MA1_beta2 <- beta_hat_MA1[3]
MA1_beta3 <- beta_hat_MA1[4]
MA1_beta4 <- beta_hat_MA1[5]
MA1_beta5 <- beta_hat_MA1[6]
MA1_sigma2_tau  <- sigma2_tau_MA1
MA1_theta1 <- theta1_MA1


MA1_estimates <- data.frame(
  Parameter = c( "beta0","beta1", "beta2", "beta3", "beta4", "beta5","sigma2_tau", "theta"),
  Estimate = c( MA1_beta0, MA1_beta1, MA1_beta2, MA1_beta3,MA1_beta4, MA1_beta5,
                MA1_sigma2_tau, MA1_theta1 ))

MA1_estimates$Estimate <- round(MA1_estimates$Estimate,3)

cat("Parameter Estimation: Poisson MA(1) Model\n")
MA1_estimates

#----------
## With SE 
#----------

rep2 = sdreport(obj2)

rep2_summary <- round(summary(rep2), 3)
MA1_estimates_SE <- tail(rep2_summary,9)
rownames(MA1_estimates_SE) <- c("beta0", "beta1", "beta2", "beta3", "beta4", "beta5","theta",
                                "sigma2_tau", "sigma_tau") 

cat("Parameter Estimation: Poisson MA1 Model with SE \n")
MA1_estimates_SE



#*************************************
#* Randomized Quantile Residuals
#*************************************

set.seed(10)

MA1_residual <- matrix( NA,nrow = n, ncol = ni)

for (i in 1:n) {
  for (j in 1:ni) {
    
    current_y  <- Y[i,j]
    current_mu <- mu_hat_MA1[i,j]
    
    lower <- ppois( q  = current_y - 1,lambda = current_mu )
    upper <- ppois( q  = current_y, lambda = current_mu)
    
    u <- runif(n = 1,min = lower, max = upper)
    
    MA1_residual[i,j] <- qnorm(u)
  }
}

res_MA1 <- MA1_residual[!is.na(MA1_residual)]
res_MA1 <- as.vector(res_MA1)

# Normal Q-Q plot
qqnorm(res_MA1, pch = 16,cex = 0.6, main = "Normal Q-Q Plot: MA(1) Model")
qqline(res_MA1,col = "red", lwd = 2)

hist(res_MA1)

# Kolmogorov-Smirnov test
KS_MA1 <- ks.test( res_MA1, "pnorm", mean = 0, sd = 1,exact = FALSE)
KS_MA1

