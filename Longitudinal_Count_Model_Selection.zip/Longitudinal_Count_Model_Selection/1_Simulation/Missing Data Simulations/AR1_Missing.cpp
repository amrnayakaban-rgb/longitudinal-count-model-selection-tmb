#include <TMB.hpp>

template<class Type>
Type objective_function<Type>::operator() ()
{
  //------------------------
  //--------- Data ---------
  //------------------------
  DATA_MATRIX(Y);      
  DATA_MATRIX(X1);    
  DATA_MATRIX(X2);
  DATA_MATRIX(delta); 
  DATA_INTEGER(n);
  DATA_INTEGER(ni);
  
  //--------------------------
  //---  Parameters  ---------
  //--------------------------
  PARAMETER_VECTOR(beta); 
  PARAMETER(logit_rho);          
  PARAMETER(log_sigma_tau);       
  PARAMETER_VECTOR(tau);          
  
  //-------------------------------
  //---  Transform parameters  ----
  //-------------------------------
  Type rho = 1 / (1 + exp(-logit_rho));   
  Type sigma2_tau = exp(log_sigma_tau);
  
  //------------------------------------
  //--- Negative log-likelihood ---
  //------------------------------------
  
  Type nll = 0.0;  
  
  //---------------------------
  // Random effects
  //---------------------------
  
  for (int i = 0; i < n; i++) {
    nll -= dnorm(tau(i), Type(0.0), sqrt(sigma2_tau), true);
  }
  

  //---------------------------
  // Poisson AR(1) likelihood
  //---------------------------
  
  for(int i = 0; i < n; i++){ 
    
    int f_obs = -1;
    
    for(int j = 0; j < ni; j++){
      if(delta(i,j) == 1){
        f_obs = j;
        break;
      }
    }
    
    if(f_obs < 0) continue; 
    
    Type mu_ij = exp(beta(0) * X1(i,f_obs) + beta(1) * X2(i,f_obs) + tau(i));
    nll -= dpois(Y(i,f_obs), mu_ij, true);
    
    int l_obs = f_obs;
    
    for(int j = f_obs + 1; j < ni; j++){
        
      if(delta(i,j) == 0) continue;
      
      Type y_prev = Y(i,l_obs);
      Type y_curr = Y(i,j);
      
      Type mu_prev = exp(beta(0)*X1(i,l_obs) + beta(1)*X2(i,l_obs) + tau(i));
      Type mu_curr = exp(beta(0)*X1(i,j) + beta(1)*X2(i,j) + tau(i));
      
      Type rho_diff = 1.0;      
      int diff = (j - l_obs);   

        for(int k = 0; k < diff; k++) {
           rho_diff = rho_diff*rho; 
        }

      Type mu_now = mu_curr - rho_diff*mu_prev;
      
      l_obs = j;
       
       

      Type s_max;
      
      if (y_prev < y_curr) {
        s_max = y_prev;
      } else {  
        s_max = y_curr;
      } 
      
      Type log_sum = Type(0.0);
      Type s = 0;
      while (s <= s_max) {
        Type lbinom = dbinom(s, y_prev, rho_diff, true);
        Type lpois = dpois(y_curr - s, mu_now, true);
        
        
        if (s == 0) log_sum = lbinom + lpois;
        else log_sum = logspace_add(log_sum, lbinom + lpois);
        
        s += 1;
      }
      
      nll -= log_sum;
    }
  }
  
  //---------------------------
  // Reporting
  //---------------------------
  REPORT(beta);
  REPORT(rho);
  REPORT(sigma2_tau);
  
  ADREPORT(beta);
  ADREPORT(rho);
  ADREPORT(sigma2_tau);
  
  return nll;
}

