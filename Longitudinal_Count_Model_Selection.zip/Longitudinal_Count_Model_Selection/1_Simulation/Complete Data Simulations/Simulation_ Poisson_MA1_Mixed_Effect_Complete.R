library(TMB)
library(MASS)

set.seed(100)

#***************************************************
#********** Primary covariate values ***************
#***************************************************

n_sim =1000
n = 100
ni = 4  

beta = c(0.5,0.5)
sigma2_tau = 0.5 
rho = 0.5
theta1 = 0.5

# Covariates X1, X2
X1 = matrix(0, nrow = n, ncol = ni)
X2 = matrix(0, nrow = n, ncol = ni)

# X1 Covariate 

for (i in 1:n) {
  for (j in 1:ni) {
    if (i <= 25) {
      if (j %in% c(1,2)) X1[i,j] = 0.5
      if (j %in% c(3,4)) X1[i,j] = 1
    } else if (i <= 75) {
      if (j == 1) X1[i,j] = -0.5
      if (j %in% c(2,3)) X1[i,j] = 0
      if (j == 4) X1[i,j] = 0.5
    } else {
      X1[i,j] <- j/(2*ni)
    }
  }
}

# X2 Covariate 

for (i in 1:n) {
  for (j in 1:ni) {
    if (i <= 50) {
      X2[i,j] = (j-2.5)/(2*ni)
    } else {
      if (j %in% c(1,2)) X2[i,j] = 0
      if (j %in% c(3,4)) X2[i,j] = 0.5
    }
  }
}

#***************************************************
#**** Poisson MA1 Mixed Effect Model ***************
#***************************************************

Poisson_MA1 = function(beta,sigma2_tau){
  
  # Response matrix
  Y = matrix(0, nrow = n, ncol = ni)
  
  theta1= 0.5
  
  # Random effects
  sigma_tau = sqrt(sigma2_tau)
  
  cov_tau <- matrix(0, ni, ni)
  for (i in 1:ni) {
    for (j in 1:ni) {
      if (i==j) cov_tau[i,j] = (1 + theta1^2)*sigma2_tau
      else if (abs(i-j) == 1) cov_tau[i,j] = theta1*sigma2_tau
      else cov_tau[i,j] = 0
    }
  }
  
  tau = matrix(0, n, ni)
  
  
  for (i in 1:n) {
    tau[i, ] = mvrnorm(1, mu = rep(0, ni), Sigma = cov_tau)
    
    for (j in 1:ni) {
      mu_ij= exp(X1[i,j]*beta[1] + X2[i,j]*beta[2] + tau[i,j])
      Y[i,j] = rpois(1, mu_ij)
    }
  }
  return(Y)
}



AICc <- matrix(NA, n_sim, 3)
colnames(AICc) <- c("AIC_AR", "AIC_MA", "AIC_EQC")

BICc <- matrix(NA, n_sim, 3)
colnames(BICc) <- c("BIC_AR", "BIC_MA", "BIC_EQC")

AR_better_AICc<-0
MA_better_AICc<-0
EQC_better_AICc<-0

AR_better_BICc<-0
MA_better_BICc<-0
EQC_better_BICc<-0


result_beta_AR<-matrix(NA,n_sim,2)
colnames(result_beta_AR)<-c("beta1","beta2")

result_sigma2_tau_AR<-matrix(NA,n_sim,1)
colnames(result_sigma2_tau_AR)<-"sigma2_tau"

result_rho_AR<-matrix(NA,n_sim,1)
colnames(result_rho_AR)<-c("rho")


result_beta_MA<-matrix(NA,n_sim,2)
colnames(result_beta_MA)<-c("beta1","beta2")

result_sigma2_tau_MA<-matrix(NA,n_sim,1)
colnames(result_sigma2_tau_MA)<-"sigma2_tau"

result_theta1_MA<-matrix(NA,n_sim,1)
colnames(result_theta1_MA)<-c("theta1")


result_beta_EQC<-matrix(NA,n_sim,2)
colnames(result_beta_EQC)<-c("beta1","beta2")

result_sigma2_tau_EQC<-matrix(NA,n_sim,1)
colnames(result_sigma2_tau_EQC)<-"sigma2_tau"



result_summary <- function(name, mean, bias, sd, rmse) {
  
  df <- data.frame(
    Parameter = name,
    Mean      = paste(round(mean, 3), collapse = ", "),
    Bias      = paste(round(bias, 3), collapse = ", "),
    SD        = paste(round(sd, 3), collapse = ", "),
    RMSE      = paste(round(rmse, 3), collapse = ", ")
  )
  
  print(df, row.names = FALSE)
}

#*************************
# Compile TMB model
#*************************

compile("AR1_Complete.cpp")
dyn.load(dynlib("AR1_Complete"))

compile("MA1_Complete.cpp")
dyn.load(dynlib("MA1_Complete"))

compile("EQC_Complete.cpp")
dyn.load(dynlib("EQC_Complete"))


#**********************************
# Simulation Study
#**********************************

error_count<-0

ii=1

while (ii <=n_sim){
  
  Y = Poisson_MA1(beta = c(0.5,0.5),sigma2_tau = 0.5)
  data = list(Y = Y, X1 = X1, X2 = X2, n = n, ni = ni)
  
  
  #=====================
  #  AR(1) Model
  #=====================
  parameters_AR <- list(
    beta = c(0, 0),
    logit_rho = 0,
    log_sigma_tau = 0,
    tau = rep(0, n))
  
  
  error_AR <- try( ( obj1 <- MakeADFun(data,parameters_AR,random = "tau",
                                       DLL="AR1_Complete",
                                       inner.control=list(maxit=50000,trace=F)) ),
                   silent=TRUE )
  
  obj1$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_AR)) {
    error_count = error_count + 1
    next
  }
  
  error_AR<-try( ( opt1<-nlminb(obj1$par,obj1$fn,obj1$gr,
                                control = list(trace=10,
                                               iter.max=10000,eval.max=10000,
                                               sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_AR)) {
    error_count = error_count + 1
    next
  }
  
  if (opt1$convergence != 0) {
    error_count = error_count + 1
    next
  }
  
  obj1$gr(opt1$par)
  rep_AR = obj1$report() 
  
  AIC_AR <- 2*opt1$objective + 2*length(obj1$par)
  BIC_AR <- 2*opt1$objective + log(length(data$Y))*length(obj1$par)
  
  
  #=====================
  #  MA(1) Model
  #=====================
  parameters_MA <- list(
    beta = c(0, 0),
    log_sigma_tau = 0,
    tau = matrix(0, nrow = n, ncol = ni),
    theta1=0)
  
  
  error_MA <- try( ( obj2 <- MakeADFun(data,parameters_MA,random = "tau",
                                       DLL="MA1_Complete",
                                       inner.control=list(maxit=50000,trace=F)) ),
                   silent=TRUE )
  
  obj2$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_MA)) {
    error_count = error_count + 1
    next
  }
  
  error_MA<-try( ( opt2<-nlminb(obj2$par,obj2$fn,obj2$gr,
                                control = list(trace=10,
                                               iter.max=10000,eval.max=10000,
                                               sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_MA)) {
    error_count = error_count + 1
    next
  }
  
  if (opt2$convergence != 0) {
    error_count = error_count + 1
    next
  }
  
  obj2$gr(opt2$par)
  rep_MA = obj2$report() 
  
  AIC_MA <- 2*opt2$objective + 2*length(obj2$par)
  BIC_MA <- 2*opt2$objective + log(length(data$Y))*length(obj2$par)
  
  #=====================
  #  EQC Model
  #=====================
  parameters_EQC <- list(
    beta = c(0, 0),
    log_sigma_tau = 0,
    tau = rep(0,n))
  
  
  error_EQC <- try( ( obj3 <- MakeADFun(data,parameters_EQC,random = "tau",
                                        DLL="EQC_Complete",
                                        inner.control=list(maxit=50000,trace=F)) ),
                    silent=TRUE )
  
  obj3$env$tracemgc <- FALSE
  
  if ('try-error' %in% class(error_EQC)) {
    error_count = error_count + 1
    next
  }
  
  error_EQC <-try( ( opt3<-nlminb(obj3$par,obj3$fn,obj3$gr,
                                  control = list(trace=10,
                                                 iter.max=10000,eval.max=10000,
                                                 sing.tol=1e-20)) ), silent=TRUE )
  
  if ('try-error' %in% class(error_EQC)) {
    error_count = error_count + 1
    next
  }
  
  if (opt3$convergence != 0) {
    error_count = error_count + 1
    next
  }
  
  obj3$gr(opt3$par)
  rep_EQC = obj3$report() 
  
  AIC_EQC <- 2*opt3$objective + 2*length(obj3$par)
  BIC_EQC <- 2*opt3$objective + log(length(data$Y))*length(obj3$par)
  
  #---------------------
  # Results
  #---------------------
  
  AICc[ii, ] <- c(AIC_AR, AIC_MA, AIC_EQC)
  BICc[ii, ] <- c(BIC_AR, BIC_MA, BIC_EQC)
  
  result_beta_AR[ii, ] <- rep_AR$beta
  result_sigma2_tau_AR[ii, ] <- rep_AR$sigma2_tau
  result_rho_AR[ii, ] <- rep_AR$rho
  
  result_beta_MA[ii, ] <- rep_MA$beta
  result_sigma2_tau_MA[ii, ] <- rep_MA$sigma2_tau
  result_theta1_MA[ii, ] <- rep_MA$theta1
  
  result_beta_EQC[ii, ] <- rep_EQC$beta
  result_sigma2_tau_EQC[ii, ] <- rep_EQC$sigma2_tau
  
  
  best_AIC = which.min(c(AIC_AR, AIC_MA, AIC_EQC))
  if (best_AIC == 1) AR_better_AICc = AR_better_AICc + 1
  if (best_AIC == 2) MA_better_AICc = MA_better_AICc + 1
  if (best_AIC == 3) EQC_better_AICc = EQC_better_AICc + 1
  
  best_BIC = which.min(c(BIC_AR, BIC_MA, BIC_EQC))
  if (best_BIC == 1) AR_better_BICc = AR_better_BICc + 1
  if (best_BIC == 2) MA_better_BICc = MA_better_BICc + 1
  if (best_BIC == 3) EQC_better_BICc = EQC_better_BICc + 1
  
  # print(paste("Simulation:", ii))
  ii <- ii + 1
  
}



# AIC and BIC Comparison 


cat("\n--- AIC comparison ---\n")
cat("AR(1) better:", AR_better_AICc, "times\n")
cat("MA(1) better:", MA_better_AICc, "times\n")
cat("EQC better:", EQC_better_AICc, "times\n")

cat("\n--- BIC comparison ---\n")
cat("AR(1) better:", AR_better_BICc, "times\n")
cat("MA(1) better:", MA_better_BICc, "times\n")
cat("EQC better:", EQC_better_BICc, "times\n")


#--------
# AR1
#--------

mean_beta_AR = colMeans(result_beta_AR)             
sd_beta_AR   = apply(result_beta_AR, 2, sd)         
Bias_beta_AR = round(mean_beta_AR - beta, 5)      
MSE_beta_AR  = round(apply(result_beta_AR, 2, var) + Bias_beta_AR^2, 5) 
RMSE_beta_AR = sqrt(MSE_beta_AR)



mean_sigma2tau_AR = mean(result_sigma2_tau_AR)             
sd_sigma2tau_AR   = sd(result_sigma2_tau_AR)         
Bias_sigma2tau_AR = round(mean_sigma2tau_AR  - sigma2_tau, 5)      
MSE_sigma2tau_AR  = round(var(result_sigma2_tau_AR) + Bias_sigma2tau_AR^2, 5) 
RMSE_sigma2tau_AR = sqrt(MSE_sigma2tau_AR)




mean_rho_AR = mean(result_rho_AR)             
sd_rho_AR   = sd(result_rho_AR)         
Bias_rho_AR = round(mean_rho_AR  - rho, 5)      
MSE_rho_AR  = round(var(result_rho_AR) + Bias_rho_AR^2, 5) 
RMSE_rho_AR = sqrt(MSE_rho_AR)





#--------
# MA1
#--------

mean_beta_MA = colMeans(result_beta_MA)             
sd_beta_MA   = apply(result_beta_MA, 2, sd)         
Bias_beta_MA = round(mean_beta_MA - beta, 5)      
MSE_beta_MA  = round(apply(result_beta_MA, 2, var) + Bias_beta_MA^2, 5) 
RMSE_beta_MA = sqrt(MSE_beta_MA)

mean_sigma2tau_MA = mean(result_sigma2_tau_MA)             
sd_sigma2tau_MA   = sd(result_sigma2_tau_MA)         
Bias_sigma2tau_MA = round(mean_sigma2tau_MA  - sigma2_tau, 5)      
MSE_sigma2tau_MA  = round(var(result_sigma2_tau_MA) + Bias_sigma2tau_MA^2, 5) 
RMSE_sigma2tau_MA = sqrt(MSE_sigma2tau_MA)


mean_theta1_MA = mean(result_theta1_MA)             
sd_theta1_MA   = sd(result_theta1_MA)         
Bias_theta1_MA = round(mean_theta1_MA  - theta1, 5)      
MSE_theta1_MA  = round(var(result_theta1_MA) + Bias_theta1_MA^2, 5) 
RMSE_theta1_MA = sqrt(MSE_theta1_MA)

#--------
# EQC
#--------

mean_beta_EQC = colMeans(result_beta_EQC)             
sd_beta_EQC  = apply(result_beta_EQC, 2, sd)         
Bias_beta_EQC = round(mean_beta_EQC - beta, 5)      
MSE_beta_EQC = round(apply(result_beta_EQC, 2, var) + Bias_beta_EQC^2, 5) 
RMSE_beta_EQC = sqrt(MSE_beta_EQC)

mean_sigma2tau_EQC = mean(result_sigma2_tau_EQC)             
sd_sigma2tau_EQC   = sd(result_sigma2_tau_EQC)         
Bias_sigma2tau_EQC = round(mean_sigma2tau_EQC  - sigma2_tau, 5)      
MSE_sigma2tau_EQC  = round(var(result_sigma2_tau_EQC) + Bias_sigma2tau_EQC^2, 5) 
RMSE_sigma2tau_EQC = sqrt(MSE_sigma2tau_EQC)




#------------------------
# Results
#------------------------

result_summary("Beta1 (AR1)", mean_beta_AR[1], Bias_beta_AR[1], sd_beta_AR[1],RMSE_beta_AR[1])
result_summary("Beta1 (MA1)", mean_beta_MA[1], Bias_beta_MA[1], sd_beta_MA[1], RMSE_beta_MA[1])
result_summary("Beta1 (EQC)", mean_beta_EQC[1], Bias_beta_EQC[1], sd_beta_EQC[1],RMSE_beta_EQC[1])

result_summary("Beta2 (AR1)", mean_beta_AR[2], Bias_beta_AR[2], sd_beta_AR[2],RMSE_beta_AR[2])
result_summary("Beta2 (MA1)", mean_beta_MA[2], Bias_beta_MA[2], sd_beta_MA[2], RMSE_beta_MA[2])
result_summary("Beta2 (EQC)", mean_beta_EQC[2], Bias_beta_EQC[2], sd_beta_EQC[2],RMSE_beta_EQC[2])


result_summary("sigma2_tau (AR1)", mean_sigma2tau_AR, Bias_sigma2tau_AR, sd_sigma2tau_AR,RMSE_sigma2tau_AR)
result_summary("sigma2_tau (MA1)", mean_sigma2tau_MA, Bias_sigma2tau_MA, sd_sigma2tau_MA,RMSE_sigma2tau_MA)
result_summary("sigma2_tau (EQC)", mean_sigma2tau_EQC, Bias_sigma2tau_EQC, sd_sigma2tau_EQC,RMSE_sigma2tau_EQC)

result_summary("rho (AR1)", mean_rho_AR, Bias_rho_AR, sd_rho_AR,RMSE_rho_AR)
result_summary("theta1 (MA1)", mean_theta1_MA, Bias_theta1_MA, sd_theta1_MA,RMSE_theta1_MA)


