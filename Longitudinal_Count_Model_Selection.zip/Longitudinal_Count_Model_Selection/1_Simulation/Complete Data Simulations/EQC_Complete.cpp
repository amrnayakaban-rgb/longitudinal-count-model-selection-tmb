#include <TMB.hpp>

template<class Type>
Type objective_function<Type>::operator() ()
{
  //------------------------
  //--------- Data ---------
  //------------------------
  DATA_MATRIX(Y);      
  DATA_MATRIX(X1);    
  DATA_MATRIX(X2);    
  DATA_INTEGER(n);
  DATA_INTEGER(ni);
  
  //--------------------------
  //---  Parameters  ---------
  //--------------------------
  PARAMETER_VECTOR(beta);          
  PARAMETER(log_sigma_tau);       
  PARAMETER_VECTOR(tau);          
   
  //-------------------------------
  //---  Transform parameters  ----
  //-------------------------------
   
   Type sigma2_tau = exp(log_sigma_tau);
  

  //-------------------------------
  //---  Negative log-likelihood  -
  //-------------------------------
  
  Type nll = 0.0;  
  
  //---------------------------
  // Random effects
  //---------------------------
  for (int i = 0; i < n; i++) {
    nll -= dnorm(tau(i), Type(0.0), sqrt(sigma2_tau), true);
  }
  
  
  for(int i=0; i<n; i++){
    for(int j=0; j<ni; j++){
      
      Type mu_ij = exp(X1(i,j)*beta(0) + X2(i,j)*beta(1) + tau(i));
      nll -= dpois(Y(i,j), mu_ij, true); 
    }
    
  }

  
  
  REPORT(beta);
  REPORT(sigma2_tau);
  
  ADREPORT(beta);
  ADREPORT(sigma2_tau);
  
  return nll;
}
